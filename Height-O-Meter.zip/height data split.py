# Combined data for easier management
all_heights = [140, 120, 60, 160, 120, 180, 100, 80, 160, 200, 80, 200, 20, 120, 160,
               100, 100, 40, 40, 100, 160, 100, 120, 120, 100, 20, 200, 140, 140,
               20, 60, 60, 20, 200, 100, 200, 80, 180, 180, 160, 160, 140, 200,
               180, 20]
all_times = [2.3, 2.23, 1.54, 2.69, 2.11, 2.71, 2.03, 2.05, 2.54, 2.94, 1.73, 2.9,
             0.68, 2.1, 2.6, 1.91, 2.09, 1.34, 1.09, 2.03, 2.51, 2.09, 2.29, 2.13,
             1.93, 1.04, 3.54, 2.3, 2.51, 0.89, 1.44, 1.64, 0.93, 3.1, 2.03, 2.78,
             1.68, 2.84, 2.7, 2.51, 2.44, 2.44, 3, 2.8, 1.08]

# Unique heights needed in test data
unique_heights = set(all_heights)

# Manually ensuring each height appears at least once in the test set
test_heights = []
test_times = []

for height in unique_heights:
    index = all_heights.index(height)
    test_heights.append(all_heights.pop(index))
    test_times.append(all_times.pop(index))

# Remaining data becomes the training set
train_heights = all_heights
train_times = all_times


print("Training Data (Heights):", train_heights)
print("Training Data (Times):", train_times)



print("Testing Data (Heights):", test_heights)
print("Testing Data (Times):", test_times)
