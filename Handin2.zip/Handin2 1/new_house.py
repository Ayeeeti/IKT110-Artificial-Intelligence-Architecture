import numpy as np

# Predict the price for a new house using pre-trained parameters
def price_model(year, remodeled, size, sold_in_month):
    # Load pre-trained model parameters
    model_data = np.load('extra/trained_model.npz')
    theta = model_data['theta']
    mean_X = model_data['mean_X']
    std_X = model_data['std_X']
    mean_y = model_data['mean_y']
    std_y = model_data['std_y']

    # Prepare house features
    house = {
        'year': float(year),  # Ensure numerical type
        'remodeled': float(remodeled),  # Ensure numerical type
        'size': float(size),  # Ensure numerical type
        'sold_in_month': float(sold_in_month)  # Ensure numerical type
    }

    # Prepare features list and ensure all features are numerical
    features = ['year', 'remodeled', 'size', 'sold_in_month']
    X = np.array([house[feature] for feature in features], dtype=float)

    # Normalize the features using the training mean and std deviation
    features_normalized = (X - mean_X) / std_X

    # Add bias term (for intercept) to the features vector
    X_with_bias = np.hstack([1, features_normalized])  # Adding a bias term as the first feature

    # Predict the price using the learned model parameters
    predicted_log_price = np.dot(X_with_bias, theta)

    # Convert the normalized predicted log price to actual price
    predicted_price = (predicted_log_price * std_y) + mean_y

    # To avoid negative predicted values
    if predicted_price < 0:
        predicted_price = 0.0

    return predicted_price

if __name__ == '__main__':
    # Example usage of price_model to predict the price of a house
    year = 1990
    remodeled = 2015
    size = 150
    sold_in_month = 11  # November

    predicted_price = price_model(year, remodeled, size, sold_in_month)
    print(f"Predicted Price: {predicted_price:.2f} NOK")
