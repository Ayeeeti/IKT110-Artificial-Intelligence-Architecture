import json
import numpy as np

def load_file(filepath):
    # Load the data from a jsonl file and return it as a list of dictionaries
    with open(filepath, 'r') as file:
        return [json.loads(line) for line in file]

# Updated fill_missing_with_mean function to handle missing values
def fill_missing_with_mean(data, numerical_keys):

    for key in numerical_keys:
        # Get all non-missing values for the key
        values = [float(entry[key]) for entry in data if entry.get(key) is not None]

        # Calculate the mean value
        if values:
            mean_value = sum(values) / len(values)
        else:
            mean_value = 0  # This handles the case where all values are missing

        # Replace missing values with the mean value
        for entry in data:
            if entry.get(key) is None:
                entry[key] = mean_value
            else:
                # Ensure all values are converted to float
                entry[key] = float(entry[key])

    return data

# Updated prepare_data function to handle outliers
def prepare_data():
    houses_data = load_file('houses.jsonl')

    # List of numerical keys in the dataset
    numerical_keys = ['year', 'remodeled', 'size', 'condition_rating', 'price']

    # Fill missing values with the mean for numerical keys
    houses_data = fill_missing_with_mean(houses_data, numerical_keys)

    # Remove outliers in the 'price' field (houses over 100 million NOK)
    houses_data = [entry for entry in houses_data if entry['price'] <= 100000000]

    # Extract features and target, ensuring all values are floats
    X = np.array([[float(entry['year']), float(entry['remodeled']), float(entry['size']), float(entry['condition_rating'])] for entry in houses_data])
    y = np.array([float(entry['price']) for entry in houses_data])

    # Normalize the features
    mean_X = np.mean(X, axis=0)
    std_X = np.std(X, axis=0)
    X_normalized = (X - mean_X) / std_X

    # Normalize target variable
    mean_y = np.mean(y)
    std_y = np.std(y)
    y_normalized = (y - mean_y) / std_y

    return X_normalized, y_normalized, mean_X, std_X, mean_y, std_y

if __name__ == '__main__':
    try:
        X, y, mean_X, std_X, mean_y, std_y = prepare_data()
        print("Data prepared successfully.")
    except ValueError as e:
        print(f"Error: {e}")
