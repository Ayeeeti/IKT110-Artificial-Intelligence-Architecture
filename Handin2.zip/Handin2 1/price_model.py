import numpy as np
import matplotlib.pyplot as plt
from data_preparation import prepare_data


def train_model():
    # Load and prepare data
    X, y, mean_X, std_X, mean_y, std_y = prepare_data()

    # Initialize parameters
    n_samples, n_features = X.shape
    theta = np.zeros(n_features + 1)  # +1 for the bias term

    # Hyperparameters
    learning_rate = 0.01
    n_epochs = 100
    batch_size = 16

    # To track loss over epochs
    loss_history = []

    # Training using Mini-Batch Gradient Descent
    for epoch in range(n_epochs):
        indices = np.arange(n_samples)
        np.random.shuffle(indices)
        X_with_bias = np.hstack([np.ones((n_samples, 1)), X])

        for start_idx in range(0, n_samples, batch_size):
            end_idx = min(start_idx + batch_size, n_samples)
            batch_indices = indices[start_idx:end_idx]
            X_batch = X_with_bias[batch_indices]
            y_batch = y[batch_indices]

            # Compute prediction and gradient for the batch
            predictions = np.dot(X_batch, theta)
            errors = predictions - y_batch
            gradient = 2 * np.dot(X_batch.T, errors) / len(X_batch)

            # Update parameters
            theta -= learning_rate * gradient

        # Calculate loss (mean squared error) for the entire dataset after each epoch
        total_predictions = np.dot(X_with_bias, theta)
        total_errors = total_predictions - y
        loss = np.mean(total_errors ** 2)
        loss_history.append(loss)

        # Print loss every 10 epochs
        if epoch % 10 == 0:
            print(f"Epoch {epoch}, Loss: {loss}")

    # Plot the loss curve
    plt.plot(range(n_epochs), loss_history, label='Loss Over Epochs')
    plt.xlabel('Epochs')
    plt.ylabel('Loss (MSE)')
    plt.title('Loss Convergence Over Time')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Save model parameters
    np.savez('extra/trained_model.npz', theta=theta, mean_X=mean_X, std_X=std_X, mean_y=mean_y, std_y=std_y)

    print("Model training completed and parameters saved.")
    return theta, mean_X, std_X, mean_y, std_y


if __name__ == '__main__':
    # Train model and save final parameters
    train_model()
