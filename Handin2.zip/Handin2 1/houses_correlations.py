import numpy as np
import json
from numba import jit
import plotly.express as px

# Load the dataset from JSONL file
def load_data(filepath):
    data_x = []
    data_y = []
    with open(filepath, 'r') as f:
        for line in f:
            house = json.loads(line)
            # Extract relevant features and target variable (price)
            features = [1.0, house['size'], house.get('remodeled_year', 0), house.get('external_storage', 0)]  # Adding intercept (1.0)
            data_x.append(features)
            data_y.append([house['price']])
    return np.array(data_x), np.array(data_y)

@jit(nopython=True)
def predict(theta, xs):
    return np.dot(xs, theta)

@jit(nopython=True)
def calculate_l2_loss(theta, xs, ys):
    loss = 0.0
    for i in range(ys.shape[0]):
        y_pred = np.dot(xs[i], theta)
        loss += (y_pred - ys[i]) ** 2
    mean_loss = loss / ys.shape[0]
    return mean_loss

@jit(nopython=True)
def gradient_of_J(theta, xs, ys):
    grad = np.zeros(theta.shape)
    for i in range(ys.shape[0]):
        y_pred = np.dot(xs[i], theta)
        error = y_pred - ys[i]
        grad += error * xs[i].reshape(-1, 1)
    mean_grad = grad / ys.shape[0]
    return mean_grad

@jit(nopython=True)
def sgd(xs, ys, theta, learning_rate=0.1, batch_size=2, n_iters=50):
    m = xs.shape[0]
    j_history = []

    for it in range(n_iters):
        indices = np.random.permutation(m)
        xs_shuffled = xs[indices]
        ys_shuffled = ys[indices]

        for i in range(0, m, batch_size):
            end = i + batch_size
            X_batch = xs_shuffled[i:end]
            y_batch = ys_shuffled[i:end]

            grad = gradient_of_J(theta, X_batch, y_batch)
            theta = theta - learning_rate * grad

        loss = calculate_l2_loss(theta, xs, ys)
        j_history.append(loss)
        print(f"Iteration {it + 1}/{n_iters}, Loss: {loss:.4f}")

    return theta, j_history

# Load data from houses.jsonl file
data_x, data_y = load_data('houses.jsonl')
n_features = data_x.shape[1]

# Initialize variables
theta = np.zeros((n_features, 1))
learning_rate = 0.01
batch_size = 2
n_iters = 50

# Run Mini-batch SGD
theta, j_history = sgd(data_x, data_y, theta, learning_rate, batch_size, n_iters)

print("Final theta values:", theta)

# Plot the result
fig = px.line(y=j_history, title="SGD Loss History")
fig.update_layout(xaxis_title="Iteration", yaxis_title="Loss")
fig.show()
