import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output, State
from new_house import price_model



import json
import pickle
import numpy as np
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px

# Load the trained model parameters
with open('theta.pkl', 'rb') as f:
    theta = pickle.load(f)

print("Trained model parameters loaded from theta.pkl.")


def predict_price_from_sgd_model(year, remodeled_year, house_color, month_number_to_marked):
    features = np.array([1.0, year, remodeled_year, month_number_to_marked])
    predicted_price = np.dot(features, theta).item()
    return f"{predicted_price:.2f} NOK"


app = dash.Dash(__name__)
app.layout = html.Div([
    html.H3(children="KKD - Real Estate Dashboard", style={'text-align': 'center'}),

    # Row 1
    html.Div([
        html.Div([
            html.H4(children="Year Built:"),
            dcc.Input(id='year', value=1990, type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Remodeled Year:"),
            dcc.Input(id='remodeled', value=2020, type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="District:"),
            dcc.Dropdown(['de6384f2575848dea1f471c973871aaa', '730baf69b1b94b708a1d8c66db0d7842',
                          'b8db95cf6df344958fff6a2a81d12fd5', '2be5cb90669d4054a0ecd0dd2256b93a'],
                         id='district_id', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),
    ], style={'display': 'flex', 'justify-content': 'space-between', 'padding': '10px 0'}),

    # Row 2
    html.Div([
        html.Div([
            html.H4(children="School ID:"),
            dcc.Dropdown(['8f7ef391e0d04facbdb7fbcfcbbf78db', '4263317cab874027baed01b792a88b4e',
                          '5f0eb97b297848a6aeb0ed13bf6e9c64', '05bb86c65fb745c29df55ea147230747'],
                         id='school_id', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Put to Market in:"),
            dcc.Dropdown(
                ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
                 'November', 'December'], id='month-to-marked', style={'width': '200px', 'height': '30px'}
            )
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="House Size (sq m):"),
            dcc.Input(id='Size', value='', type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),
    ], style={'display': 'flex', 'justify-content': 'space-between', 'padding': '10px 0'}),

    # Row 3
    html.Div([
        html.Div([
            html.H4(children="House Color:"),
            dcc.Dropdown(['Black', 'Blue', 'Gray', 'Green', 'Red', 'White', 'Unknown', 'Other'], id='color',
                         style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Parking Space:"),
            dcc.Dropdown(['Yes', 'No'], id='Parking', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="External Storage (sq m):"),
            dcc.Input(id='external_storage', value='', type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),
    ], style={'display': 'flex', 'justify-content': 'space-between', 'padding': '10px 0'}),

    # Row 4
    html.Div([
        html.Div([
            html.H4(children="Sun Factor:"),
            dcc.Input(id='sun_factor', value='', type='number', min=0, max=1,
                      style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Number of Rooms:"),
            dcc.Input(id='Rooms', value='0', type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Number of Bathrooms:"),
            dcc.Input(id='Bathroom', value='1', type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),
    ], style={'display': 'flex', 'justify-content': 'space-between', 'padding': '10px 0'}),

    # Row 5
    html.Div([
        html.Div([
            html.H4(children="Size of Front Yard (sq m):"),
            dcc.Input(id='lot_w', value='0', type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Number of Kitchens:"),
            dcc.Input(id='Kitchen', value='1', type='number', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),

        html.Div([
            html.H4(children="Fireplace:"),
            dcc.Dropdown(['Yes', 'No'], id='Fireplace', style={'width': '200px', 'height': '30px'})
        ], style={'flex': '1', 'padding': '10px'}),
    ], style={'display': 'flex', 'justify-content': 'space-between', 'padding': '10px 0'}),

    # Predicted Price Section
    html.Div([
        html.H4(children="Predicted Price:"),
        html.Pre(id="output-price", style={'padding': '10px', 'border': '1px solid #ccc', 'border-radius': '5px'})
    ], style={'margin-top': '20px'}),
])

@app.callback(Output('output-price', 'children'),
              [Input('year', 'value'),
               Input('remodeled', 'value'),
               Input('color', 'value'),
               Input('month-to-marked', 'value')])
def predict_price(year, remodeled, house_color, month_to_marked):
    if year is None or remodeled is None or house_color is None or month_to_marked is None:
        return "Please fill in all fields."

    # Mapping month names to numbers
    month_mapping = {
        "January": 1, "February": 2, "March": 3, "April": 4, "May": 5, "June": 6,
        "July": 7, "August": 8, "September": 9, "October": 10, "November": 11, "December": 12
    }
    month_number_to_marked = month_mapping.get(month_to_marked, 12)

    return predict_price_from_sgd_model(year, remodeled, house_color, month_number_to_marked)

if __name__ == '__main__':
    app.run_server(debug=True)




app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("KKD Real Estate Price Prediction"),
    html.Label("Year Built:"),
    dcc.Input(id='year-input', type='number', value=1980),
    html.Label("Year Remodeled:"),
    dcc.Input(id='remodeled-input', type='number', value=2024),
    html.Label("Size (sqm):"),
    dcc.Input(id='size-input', type='number', value=1050),
    html.Label("Sold In Month (1-12):"),
    dcc.Input(id='month-input', type='number', value=5, min=1, max=12),
    html.Button('Predict Price', id='predict-button', n_clicks=0),
    html.Div(id='prediction-output')
])

@app.callback(
    Output('prediction-output', 'children'),
    [Input('predict-button', 'n_clicks')],
    [State('year-input', 'value'),
     State('remodeled-input', 'value'),
     State('size-input', 'value'),
     State('month-input', 'value')]
)
def predict_price(n_clicks, year, remodeled, size, month):
    if n_clicks > 0:
        predicted_price = price_model(year, remodeled, size, month)
        return f"Predicted Price: {predicted_price:.2f} NOK"
    return ""

if __name__ == '__main__':
    app.run_server(debug=True)
