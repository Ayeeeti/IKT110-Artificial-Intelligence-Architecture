import json
import numpy as np
import math
from collections import Counter

# Noe galt med json filen så bare skrev inn dataen
schools=[
{"id": "8f7ef391e0d04facbdb7fbcfcbbf78db", "district_id": "de6384f2575848dea1f471c973871aaa", "built_year": 1979, "rating": 1.8, "capacity": 13},
{"id": "4263317cab874027baed01b792a88b4e", "district_id": "730baf69b1b94b708a1d8c66db0d7842", "built_year": 1997, "rating": 3.3, "capacity": 59},
{"id": "5f0eb97b297848a6aeb0ed13bf6e9c64", "district_id": "b8db95cf6df344958fff6a2a81d12fd5", "built_year": 1949, "rating": 1.9, "capacity": 27},
{"id": "05bb86c65fb745c29df55ea147230747", "district_id": "2be5cb90669d4054a0ecd0dd2256b93a", "built_year": 1947, "rating": 3.5, "capacity": 3},
{"id": "837e7b0dea49434ca8a0b657862c25f0", "district_id": "b8db95cf6df344958fff6a2a81d12fd5", "built_year": 1976, "rating": 3.5, "capacity": 68},
{"id": "fc63d791a5404f3a85bd059df4a6eb4c", "district_id": "b8db95cf6df344958fff6a2a81d12fd5", "built_year": 1934, "rating": 2.8, "capacity": 22},
{"id": "5921cc4350cc4ec599840b3ccf72cf6a", "district_id": "2be5cb90669d4054a0ecd0dd2256b93a", "built_year": 2000, "rating": 3.4, "capacity": 72},
{"id": "91df0eeb2d884e2e809c2e4e0eccb845", "district_id": "2be5cb90669d4054a0ecd0dd2256b93a", "built_year": 1983, "rating": 2.2, "capacity": 49},
{"id": "d80794c4bc5a4bc98983fb85e4896b93", "district_id": "2be5cb90669d4054a0ecd0dd2256b93a", "built_year": 1937, "rating": 3.1, "capacity": 88},
{"id": "76f73bf6e2b24a22a4f1d9f022ad3d2c", "district_id": "730baf69b1b94b708a1d8c66db0d7842", "built_year": 1947, "rating": 3.7, "capacity": 28}
]


# Scales a feature
def standardize_feature(values):
    mean = sum(values) / len(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    std_dev = math.sqrt(variance)
    return [(x - mean) / std_dev for x in values]

# Finds the correlation between two features
def calculate_correlation(x, y):
    mean_x = sum(x) / len(x)
    mean_y = sum(y) / len(y)
    covariance = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(len(x))) / len(x)
    std_dev_x = math.sqrt(sum((x[i] - mean_x) ** 2 for i in range(len(x))) / len(x))
    std_dev_y = math.sqrt(sum((y[i] - mean_y) ** 2 for i in range(len(y))) / len(y))
    return covariance / (std_dev_x * std_dev_y)

# Handle missing data: Count missing values in each field
data_schools_miss = {key: 0 for key in schools[0].keys()}
for item in schools:
    for key, value in item.items():
        if value is None:
            data_schools_miss[key] += 1

print("\nMissing data: ")
print(data_schools_miss)

# Extract features for standardization
built_years = [item['built_year'] for item in schools]
ratings = [item['rating'] for item in schools]
capacities = [item['capacity'] for item in schools]

# Scales numeric features
std_built_years = standardize_feature(built_years)
std_ratings = standardize_feature(ratings)
std_capacities = standardize_feature(capacities)

# Update scaled features in the dataset
for i in range(len(schools)):
    schools[i]['std_built_year'] = std_built_years[i]
    schools[i]['std_rating'] = std_ratings[i]
    schools[i]['std_capacity'] = std_capacities[i]

# Print scaled data
print("\nCleaned and Standardized Data:")
for school in schools:
    print(school)

# Calculate correlation matrix
correlation_matrix = {
    'built_year': {
        'built_year': calculate_correlation(std_built_years, std_built_years),
        'rating': calculate_correlation(std_built_years, std_ratings),
        'capacity': calculate_correlation(std_built_years, std_capacities)
    },
    'rating': {
        'built_year': calculate_correlation(std_ratings, std_built_years),
        'rating': calculate_correlation(std_ratings, std_ratings),
        'capacity': calculate_correlation(std_ratings, std_capacities)
    },
    'capacity': {
        'built_year': calculate_correlation(std_capacities, std_built_years),
        'rating': calculate_correlation(std_capacities, std_ratings),
        'capacity': calculate_correlation(std_capacities, std_capacities)
    }
}

# Print correlation matrix
print("\nCorrelation Matrix:")
for key1, value1 in correlation_matrix.items():
    for key2, value2 in value1.items():
        print(f"{key1} - {key2}: {value2}")