import pickle

import numpy as np
import json
from numba import jit
import plotly.express as px
import plotly.graph_objects as go

# Load the dataset from JSONL file
def load_data(filepath):
    data_x = []
    data_y = []
    with open(filepath, 'r') as f:
        for line in f:
            house = json.loads(line)

            # Extract features, handle missing keys using default values
            year = house.get('year', 0)  # Default to 0 if 'year' is missing
            remodeled_year = house.get('remodeled', 0)  # Default to 0 if 'remodeled' is missing
            sun_factor = house.get('sun_factor', 0)  # Default to 0 if 'sun_factor' is missing
            price = house.get('price')

            # If 'price' is missing, skip this entry
            if price is None:
                continue

            # Construct the features list
            features = [1.0, year, remodeled_year, sun_factor]  # Adding intercept (1.0)
            data_x.append(features)
            data_y.append(price)

    return np.array(data_x), np.array(data_y)

# Loading data from houses.jsonl
data_x, data_y = load_data('houses.jsonl')

@jit(nopython=True)
def predict(theta, xs):
    return np.dot(xs, theta)

@jit(nopython=True)
def gradient_of_J(theta, xs, ys):
    m = ys.shape[0]
    gradients = np.zeros(theta.shape)
    for i in range(m):
        y_hat = np.dot(xs[i], theta)
        dLdy = (y_hat - ys[i])
        gradients += dLdy * xs[i]
    return gradients / m

@jit(nopython=True)
def calculate_l2_loss(theta, xs, ys):
    m = ys.shape[0]
    loss = 0.0
    for i in range(m):
        y_pred = np.dot(xs[i], theta).item()  # Convert y_pred to a scalar
        loss += (y_pred - ys[i]) ** 2  # ys[i] is now a scalar
    return loss / (2 * m)

def sgd_model(xs, ys, theta, learning_rate=0.01, batch_size=2, n_iters=50):
    m = xs.shape[0]
    j_history = []

    for it in range(n_iters):
        indices = np.random.permutation(m)
        xs_shuffled = xs[indices]
        ys_shuffled = ys[indices]

        for i in range(0, m, batch_size):
            end = i + batch_size
            X_batch = xs_shuffled[i:end]
            y_batch = ys_shuffled[i:end]

            grad = gradient_of_J(theta, X_batch, y_batch)
            theta = theta - (learning_rate * grad)

        # Calculate loss after each iteration
        loss = calculate_l2_loss(theta, xs, ys)
        j_history.append(loss)

        print(f"Iteration {it+1}/{n_iters}, Loss: {loss:.4f}")

    return theta, j_history

    # Save the trained model parameters
    with open('theta.pkl', 'wb') as f:
        pickle.dump(theta, f)

    print("Trained model parameters saved to theta.pkl.")


# Initialize variables
n_features = data_x.shape[1]
theta = np.zeros((n_features, 1))
learning_rate = 0.01
batch_size = 2
n_iters = 50

# Run SGD
theta, j_history = sgd_model(data_x, data_y, theta, learning_rate, batch_size, n_iters)

# Plot the loss history
loss_x = np.arange(len(j_history))
fig = px.line(x=loss_x, y=j_history, title="SGD Loss History")
fig.show()


