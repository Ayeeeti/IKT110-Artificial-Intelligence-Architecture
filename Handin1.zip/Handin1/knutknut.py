import json
import numpy as np
import random
import matplotlib.pyplot as plt
import time


def l2_loss(y_left, y_right):
    total_samples = len(y_left) + len(y_right)
    if total_samples == 0:
        return float('inf')
    loss = 0
    for y_set in [y_left, y_right]:
        if len(y_set) == 0:
            continue
        mean_value = np.mean(y_set)
        loss += np.sum((y_set - mean_value) ** 2)
    return loss

def find_split(xs, ys, random_splits=1000):
    n_samples, n_features = xs.shape
    best_loss = float('inf')
    best_split = None
    rng = np.random.default_rng(42)

    for i in range(random_splits):
        feature_i = rng.integers(0, n_features)
        threshold = rng.uniform(0, 1)
        left_is = xs[:, feature_i] <= threshold
        right_is = xs[:, feature_i] > threshold
        # check to avoid empty splits
        if np.sum(left_is) == 0 or np.sum(right_is) == 0:
            continue
        y_left = ys[left_is]
        y_right = ys[right_is]
        loss = l2_loss(y_left, y_right)
        if loss < best_loss:
            best_loss = loss
            best_split = {
                'feature_index': feature_i,
                'threshold': threshold,
                'left_index': left_is,
                'right_index': right_is
            }
    return best_split



def build_tree(xs, ys, depth=0, max_depth=4, random_splits=1000):
    if len(np.unique(ys)) == 1 or depth > max_depth:
        prediction = np.mean(ys)
        return {'prediction': prediction}
    split = find_split(xs, ys, random_splits)
    if split is None:
        prediction = np.mean(ys)
        return {'prediction': prediction}
    left_tree = build_tree(xs[split['left_index']], ys[split['left_index']], depth + 1, max_depth, random_splits)
    right_tree = build_tree(xs[split['right_index']], ys[split['right_index']], depth + 1, max_depth, random_splits)
    return {
        'feature_index': split['feature_index'],
        'threshold': split['threshold'],
        'left': left_tree,
        'right': right_tree
    }


def predict(tree, x):
    while 'prediction' not in tree:
        if x[tree['feature_index']] <= tree['threshold']:
            tree = tree['left']
        else:
            tree = tree['right']
    return int(round(tree['prediction']))

# converting time to minutes since midnight
def convert_time_to_minutes(t):
    h_str = t[0]+t[1]
    m_str = t[3]+t[4]
    total_minutes = int(h_str)*60 + int(m_str)
    return total_minutes

# Read traffic.jsonl
traffic = {'raw_data': []}  #
with open('traffic.jsonl', 'r') as f:
    for line in f:
        traffic['raw_data'].append(json.loads(line))

random.shuffle(traffic['raw_data'])
split = int(len(traffic['raw_data']) * 0.8)
train_traffic = traffic['raw_data'][:split]
test_traffic = traffic['raw_data'][split:]

    # Prepare features and targets for the decision tree model
def prepare_data_for_route(route_data):
    xs = np.array([convert_time_to_minutes(item['depature']) for item in route_data]).reshape(-1, 1)
    ys = np.array([convert_time_to_minutes(item['arrival']) - convert_time_to_minutes(item['depature']) for item in route_data])
    return xs, ys


# Train models for each route and evaluate on training and test sets
ACD = [item for item in traffic['raw_data'] if item['road'] == 'A->C->D']
ACE = [item for item in traffic['raw_data'] if item['road'] == 'A->C->E']
BCD = [item for item in traffic['raw_data'] if item['road'] == 'B->C->D']
BCE = [item for item in traffic['raw_data'] if item['road'] == 'B->C->E']

routes = {'ACD': ACD, 'ACE': ACE, 'BCD': BCD, 'BCE': BCE}
trees = {}

def evaluate_model(tree, xs, ys):
    predictions = np.array([predict(tree, x) for x in xs])
    accuracy = np.mean(predictions == ys)*100
    l2 = np.sum((ys - predictions) ** 2)
    return accuracy, l2


for route_name, route_data in routes.items():
    print(f"\nTraining for route: {route_name}")
    xs_train, ys_train = prepare_data_for_route(route_data)
    tree = build_tree(xs_train, ys_train, max_depth=4, random_splits=1000)
    trees[route_name] = tree

    train_accuracy, train_loss = evaluate_model(tree, xs_train, ys_train)
    print(f"Route: {route_name}, Train Accuracy: {train_accuracy}, Train Loss: {train_loss}")

    xs_test, ys_test = prepare_data_for_route(test_traffic)
    test_accuracy, test_loss = evaluate_model(tree, xs_test, ys_test)
    print(f"Route: {route_name}, Test Accuracy: {test_accuracy}, Test Loss: {test_loss}")

def predict_fastest_route(departure_time):
    departure_time = convert_time_to_minutes(departure_time)
    best_route = None
    best_time = float('inf')

    for route_name, tree in trees.items():
        predicted_time = predict(tree, np.array([departure_time]))
        if predicted_time < best_time:
            best_route = route_name
            best_time = predicted_time
    return best_route, best_time

departure_time = '08:30'
best_route, estimated_time = predict_fastest_route(departure_time)
print(f"Best route: {best_route}, Estimated time: {estimated_time} at {departure_time}")
