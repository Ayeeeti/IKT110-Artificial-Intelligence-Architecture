import pickle
from flask import Flask, request
from task_6 import find_best_route, routes_data  # Only import find_best_route and routes_data

app = Flask(__name__)

# Load trained parameters
with open('thetas.pkl', 'rb') as f:
    thetas = pickle.load(f)

# Use the loaded thetas for predictions
def get_the_best_route_as_a_text_informatic(dep_hour, dep_min):
    try:
        departure_time = int(dep_hour) * 60 + int(dep_min)
        best_route, best_duration, best_cost = find_best_route(departure_time, routes_data, thetas)

        out = """
        <p>
        Departure time: {}:{} <br> 
        Best travel route: {} <br> 
        Estimated travel time: {} minutes <br>
        Estimated cost: {:.2f} NOK
        </p> 
        <p><a href="/">Back</a></p>
        """.format(dep_hour.zfill(2), dep_min.zfill(2), best_route, round(best_duration, 2), best_cost)

    except Exception as e:
        out = f"<p>Error in processing: {str(e)}</p><p><a href='/'>Back</a></p>"

    return out

@app.route('/')
def get_departure_time():
    return """
       <h3>Knut Knut Transport AS</h3>
       <form action="/get_best_route" method="get" style="font-size: 20px">
           <label for="hour">Hour:</label>
           <select name="hour" id="hour" style="font-size: 18px">
               <option value="06">06</option>
               <option value="07">07</option>
               <option value="08">08</option>
               <option value="09">09</option>
               <option value="10">10</option>
               <option value="11">11</option>
               <option value="12">12</option>
               <option value="13">13</option>
               <option value="14">14</option>
               <option value="15">15</option>
               <option value="16">16</option>     
           </select>

           <label for="mins">Mins:</label>
           <input type="text" name="mins" size="2" style="font-size: 18px"/>
           <input type="submit" style="font-size: 18px">
       </form>
    """

@app.route("/get_best_route")
def get_route():
    departure_h = request.args.get('hour')
    departure_m = request.args.get('mins')
    route_info = get_the_best_route_as_a_text_informatic(departure_h, departure_m)
    return route_info

if __name__ == '__main__':
    print("<starting>")
    app.run()
    print("<done>")
