import json
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import time
import random

#function that converts a time-of-day to minutes-since-midnight
def convert_time_to_minutes(t):
    h_str = t[0]+t[1]
    m_str = t[3]+t[4]
    total_minutes= int(h_str)*60+int(m_str)

    return total_minutes




#finds and reads the json file
with open('traffic (1).jsonl', 'r') as f:
    traffic = json.load(f)


random.shuffle(traffic['raw_data'])
split = int(len(traffic['raw_data'])*0.8)
train_traffic = traffic['raw_data'][:split]
test_traffic = traffic['raw_data'][split:]


#makes empty lists for the different routes
ACD = []
ACE = []
BCD = []
BCE = []
error = []

#loops through each trip (item) in the json-array "raw_data" and appends them to the correct route
for i in traffic['raw_data']:
    if i['road'] == 'A->C->D':
        ACD.append(i)
    elif i['road'] == 'A->C->E':
        ACE.append(i)
    elif i['road'] == 'B->C->D':
        BCD.append(i)
    elif i['road'] == 'B->C->E':
        BCE.append(i)
    else:
        error.append(i)



ACD_departed_minutes = []
ACE_departed_minutes = []
BCD_departed_minutes = []
BCE_departed_minutes = []

#ACD - sorts and finds the x-points (departure) and y-points
ACD_unsorted = ACD
ACD_sorted = []
ACD_departure_sorted = []
ACD_duration_sorted = []


while len(ACD_sorted) < len(ACD_unsorted):
    fewest_minutes = 2000
    for i in ACD_unsorted:
        minutes = convert_time_to_minutes(i['departure'])
        if minutes < fewest_minutes:
            fewest_minutes = minutes
            earliest_i = i
            earliest_departure = i['departure']
            earliest_arrival = i['arrival']
    ACD_sorted.append(earliest_i)
    ACD_departure_sorted.append(earliest_departure)
    ACD_duration_sorted.append(convert_time_to_minutes(earliest_arrival)-convert_time_to_minutes(earliest_departure))
    ACD_departed_minutes.append(convert_time_to_minutes(earliest_departure))
    ACD_unsorted.remove(earliest_i)


ACE_unsorted = ACE
ACE_sorted = []
ACE_departure_sorted = []
ACE_duration_sorted = []

while len(ACE_sorted) < len(ACE_unsorted):
    fewest_minutes = 2000
    for i in ACE_unsorted:
        minutes = convert_time_to_minutes(i['departure'])
        if minutes < fewest_minutes:
            fewest_minutes = minutes
            earliest_i = i
            earliest_departure = i['departure']
            earliest_arrival = i['arrival']
    ACE_sorted.append(earliest_i)
    ACE_departure_sorted.append(earliest_departure)
    ACE_duration_sorted.append(convert_time_to_minutes(earliest_arrival)-convert_time_to_minutes(earliest_departure))
    ACE_departed_minutes.append(convert_time_to_minutes(earliest_departure))
    ACE_unsorted.remove(earliest_i)


BCD_unsorted = BCD
BCD_sorted = []
BCD_departure_sorted = []
BCD_duration_sorted = []

while len(BCD_sorted) < len(BCD_unsorted):
    fewest_minutes = 2000
    for i in BCD_unsorted:
        minutes = convert_time_to_minutes(i['departure'])
        if minutes < fewest_minutes:
            fewest_minutes = minutes
            earliest_i = i
            earliest_departure = i['departure']
            earliest_arrival = i['arrival']
    BCD_sorted.append(earliest_i)
    BCD_departure_sorted.append(earliest_departure)
    BCD_duration_sorted.append(convert_time_to_minutes(earliest_arrival)-convert_time_to_minutes(earliest_departure))
    BCD_departed_minutes.append(convert_time_to_minutes(earliest_departure))
    BCD_unsorted.remove(earliest_i)


BCE_unsorted = BCE
BCE_sorted = []
BCE_departure_sorted = []
BCE_duration_sorted = []

while len(BCE_sorted) < len(BCE_unsorted):
    fewest_minutes = 2000
    for i in BCE_unsorted:
        minutes = convert_time_to_minutes(i['departure'])
        if minutes < fewest_minutes:
            fewest_minutes = minutes
            earliest_i = i
            earliest_departure = i['departure']
            earliest_arrival = i['arrival']
    BCE_sorted.append(earliest_i)
    BCE_departure_sorted.append(earliest_departure)
    BCE_duration_sorted.append(convert_time_to_minutes(earliest_arrival)-convert_time_to_minutes(earliest_departure))
    BCE_departed_minutes.append(convert_time_to_minutes(earliest_departure))
    BCE_unsorted.remove(earliest_i)

print("ACD")
print("x", ACD_departed_minutes)
print("y", ACD_duration_sorted)

print("ACE")
print("x", ACE_departed_minutes)
print("y", ACE_duration_sorted)

print("BCD")
print("x", BCD_departed_minutes)
print("y", BCD_duration_sorted)


print("BCE")
print("x", BCE_departed_minutes)
print("y", BCE_duration_sorted)





#ACD
ax = plt.axes()
ax.plot(ACD_departure_sorted, ACD_duration_sorted)

fmt = ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x)))
ax.xaxis.set_major_formatter(fmt)
plt.ylim(50,180)

plt.show()


#ACE
ax = plt.axes()
ax.plot(ACE_departure_sorted, ACE_duration_sorted)

fmt = ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x)))
ax.xaxis.set_major_formatter(fmt)
plt.ylim(50,180)

plt.show()


#BCD
ax = plt.axes()
ax.plot(BCD_departure_sorted, BCD_duration_sorted)

fmt = ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x)))
ax.xaxis.set_major_formatter(fmt)
plt.ylim(50,180)

plt.show()


#BCE
ax = plt.axes()
ax.plot(BCE_departure_sorted, BCE_duration_sorted)

fmt = ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x)))
ax.xaxis.set_major_formatter(fmt)
plt.ylim(50,180)

plt.show()
