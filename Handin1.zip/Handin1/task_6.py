import numpy as np
import matplotlib.pyplot as plt
import tqdm
import random


random.seed(42)
np.random.seed(42)

# Log function for ACD
def predict_acd(x, theta):
    a, b, c = theta  # parameters for the  model
    y_hat = a * np.log(x + b) + c
    return y_hat


# Linear function for ACE
def predict_ace(x, theta):
    m, c = theta  # Slope and intercept for linear function
    y_hat = m * x + c
    return y_hat

#sin funksjon for bcd
def predict_bcd(x, theta):
    psi, gamma, omega = theta[:12], theta[12:24], theta[24:36]
    y_hat = np.zeros_like(x, dtype=float)
    for k in range(12):  # Sum of 12 sin waves
        y_hat += psi[k] * np.sin(gamma[k] * (x + omega[k]))
    return y_hat

# Sin funksjon for bce
def predict_bce(x, theta):
    psi, gamma, omega = theta[:12], theta[12:24], theta[24:36]
    y_hat = np.zeros_like(x, dtype=float)
    for k in range(12):  # Sum of 12 sin waves
        y_hat += psi[k] * np.sin(gamma[k] * (x + omega[k]))
    return y_hat


# to return the appropriate model for each route
def predict(route, x, theta):
    if route == 'ACD':
        return predict_acd(x, theta)
    elif route == 'ACE':
        return predict_ace(x, theta)
    elif route == 'BCD':
        return predict_bcd(x, theta)
    elif route == 'BCE':
        return predict_bce(x, theta)


# Calculate the loss
def get_loss(y_hat, ys):
    return np.mean((y_hat - ys) ** 2)

#  For adjusting the parameters
def sample_theta(route):
    if route == 'ACD':
        return np.random.uniform(-10, 10, size=3)
    elif route == 'ACE':
        return np.random.uniform(-10, 10, size=2)
    elif route == 'BCD':
        psi = np.random.uniform(20, 60, size=12)
        gamma = np.random.uniform(0.0005, 0.01, size=12)
        omega = np.random.uniform(0, 2 * np.pi, size=12)
        return np.concatenate([psi, gamma, omega])
    elif route == 'BCE':
        psi = np.random.uniform(20, 60, size=12)
        gamma = np.random.uniform(0.0005, 0.01, size=12)
        omega = np.random.uniform(0, 2 * np.pi, size=12)
        return np.concatenate([psi, gamma, omega])


# Function to estimate trip cost
def estimate_trip_cost(time_minutes, avg_speed=60, fuel_consumption_rate=0.6, fuel_price=17.77):
    # Calculate distance in km using route duration in minutes
    distance = (avg_speed * time_minutes) / 60
    # Calculate the fuel consumption in liters
    fuel_consumed = distance * fuel_consumption_rate
    # Calculate the cost of the trip
    cost = fuel_consumed * fuel_price
    return cost

routes_data = {
   'ACD': {
       'xs': np.array([423, 424, 426, 427, 436, 442, 444, 445, 446, 450, 452,
                       453, 457, 462, 464, 468, 469, 470, 471, 479, 486, 487,
                       488, 490, 502, 505, 510, 511, 512, 513, 515, 516, 520,
                       520, 524, 524, 526, 528, 530, 532, 533, 540, 542, 547,
                       557, 559, 559, 560, 560, 561, 563, 569, 573, 574, 579,
                       580, 581, 582, 582, 584, 585, 587, 590, 591, 592, 593,
                       597, 597, 598, 598, 601, 604, 609, 619, 627, 628, 631,
                       636, 640, 643, 649, 651, 653, 655, 656, 659, 659, 660,
                       662, 662, 663, 669, 674, 676, 678, 683, 685, 689, 691,
                       692, 692, 692, 694, 695, 695, 695, 699, 702, 702, 703,
                       704, 704, 705, 710, 712, 713, 715, 715, 716, 716, 718,
                       720, 721, 728, 731, 732]
),
       'ys': np.array([127, 121, 120, 133, 124, 125, 124, 127, 123, 130, 124,
                       126, 118, 121, 130, 117, 123, 128, 124, 124, 127, 114,
                       117, 126, 103, 115, 108, 116, 109, 109, 109, 107, 108,
                       103, 102, 102, 103, 98, 102, 107, 104, 102, 95, 103, 98,
                       96, 89, 94, 91, 91, 96, 96, 95, 81, 87, 83, 78, 87, 80,
                       89, 84, 85, 78, 88, 86, 88, 83, 80, 85, 79, 85, 86, 74,
                       86, 72, 76, 76, 79, 80, 74, 80, 83, 82, 72, 69, 76, 74,
                       74, 73, 85, 71, 83, 79, 79, 82, 81, 83, 78, 73, 78, 77,
                       83, 79, 73, 72, 76, 73, 74, 79, 73, 70, 77, 72, 74, 70,
                       80, 79, 80, 71, 72, 77, 86, 78, 75, 80, 70]
)
   },
   'ACE': {
       'xs': np.array([421, 424, 427, 428, 431, 435, 436, 436, 444, 445, 449,
                       451, 454, 467, 471, 472, 473, 475, 477, 478, 479, 479,
                       483, 490, 492, 492, 494, 494, 499, 499, 501, 502, 504,
                       509, 509, 514, 516, 516, 517, 517, 517, 518, 519, 520,
                       521, 522, 524, 526, 528, 534, 535, 535, 537, 545, 549,
                       549, 549, 549, 558, 560, 560, 564, 569, 571, 574, 576,
                       577, 577, 579, 582, 583, 584, 587, 589, 589, 594, 594,
                       596, 609, 609, 612, 620, 622, 623, 624, 624, 625, 628,
                       628, 629, 631, 638, 638, 640, 641, 642, 643, 645, 648,
                       650, 654, 655, 656, 664, 669, 674, 675, 675, 677, 678,
                       679, 685, 692, 697, 698, 702, 705, 707, 714, 714, 714,
                       714, 716, 717, 721, 722, 722, 727, 731, 732, 734, 734]),
       'ys': np.array([87, 103, 100, 102, 95, 105, 98, 100, 104, 99, 99, 95, 98,
                       98, 99, 99, 99, 99, 98, 102, 98, 93, 91, 96, 101, 101, 96,
                       98, 96, 101, 105, 96, 102, 91, 91, 100, 94, 103, 103, 104,
                       91, 95, 96, 105, 91, 104, 94, 100, 92, 95, 96, 104, 101,
                       102, 103, 102, 101, 104, 96, 92, 99, 95, 98, 98, 99, 100,
                       99, 96, 102, 98, 100, 100, 102, 99, 99, 100, 90, 99, 89,
                       98, 98, 93, 98, 96, 94, 101, 94, 103, 88, 86, 102, 95, 93,
                       107, 102, 104, 96, 97, 93, 92, 90, 95, 93, 93, 93, 97, 97,
                       105, 95, 97, 97, 98, 103, 91, 96, 104, 103, 99, 89, 99, 94,
                       101, 96, 90, 105, 100, 91, 100, 101, 93, 93, 91])
   },
   'BCD': {
       'xs': np.array([420, 421, 424, 430, 435, 439, 439, 441, 445, 451, 451,
                       453, 455, 457, 462, 463, 464, 467, 467, 467, 474, 476,
                       487, 487, 489, 494, 495, 498, 499, 500, 501, 502, 503,
                       503, 506, 506, 506, 509, 509, 512, 516, 517, 517, 519,
                       520, 521, 526, 529, 533, 534, 539, 542, 543, 544, 544,
                       544, 549, 549, 550, 550, 551, 554, 558, 558, 562, 564,
                       565, 565, 571, 572, 578, 579, 579, 583, 587, 591, 591,
                       595, 595, 596, 599, 601, 609, 609, 618, 621, 621, 625,
                       629, 632, 633, 636, 638, 639, 639, 649, 650, 658, 658,
                       660, 661, 664, 665, 665, 666, 669, 670, 671, 675, 676,
                       676, 677, 679, 684, 684, 698, 698, 699, 702, 704, 704,
                       706, 706, 713, 713, 714, 715, 719, 723, 724]),
       'ys': np.array([112, 112, 113, 106, 104, 155, 155, 153, 149, 142, 144,
                       142, 142, 134, 132, 131, 129, 122, 129, 126, 117, 121,
                       102, 96, 96, 94, 97, 151, 143, 141, 145, 146, 137, 140,
                       134, 138, 139, 132, 130, 129, 121, 128, 123, 120, 116,
                       117, 110, 106, 94, 95, 96, 94, 84, 83, 88, 87, 77, 79,
                       80, 78, 77, 72, 126, 133, 121, 121, 122, 120, 115, 108,
                       101, 102, 103, 98, 91, 84, 85, 80, 76, 80, 70, 72, 64,
                       63, 117, 106, 107, 98, 96, 95, 91, 94, 85, 87, 86, 76,
                       76, 70, 68, 70, 68, 63, 67, 64, 63, 59, 54, 53, 50, 109,
                       114, 111, 108, 101, 103, 90, 93, 85, 86, 83, 83, 81, 77,
                       75, 80, 76, 77, 69, 65, 67])
   },
   'BCE': {
       'xs': np.array([420, 420, 421, 422, 426, 430, 432, 434, 445, 445, 451, 452, 453,
                       463, 467, 467, 468, 470, 470, 470, 472, 473, 473, 474, 475, 482,
                       486, 496, 501, 501, 501, 505, 507, 507, 507, 508, 520, 522, 522,
                       524, 530, 533, 535, 536, 538, 538, 541, 542, 542, 543, 543, 547,
                       549, 549, 552, 554, 555, 556, 566, 567, 568, 574, 575, 576, 576,
                       584, 584, 585, 587, 587, 589, 591, 594, 596, 599, 600, 601, 602,
                       603, 603, 604, 607, 612, 615, 617, 617, 617, 619, 620, 621, 623,
                       625, 625, 635, 637, 638, 638, 640, 644, 647, 648, 649, 650, 651,
                       653, 653, 660, 661, 672, 673, 675, 683, 685, 686, 688, 689, 692,
                       693, 695, 695, 698, 700, 702, 703, 705, 708, 711, 715, 722]),
       'ys': np.array([93, 89, 84, 89, 81, 80, 74, 76, 124, 121, 116, 113, 117, 102, 104,
                       102, 103, 102, 95, 98, 103, 90, 94, 91, 93, 88, 82, 137, 130, 128,
                       127, 124, 123, 118, 115, 115, 110, 108, 106, 103, 100, 101, 93, 91,
                       86, 95, 88, 80, 86, 85, 82, 77, 78, 81, 74, 79, 76, 134, 124, 120,
                       125, 112, 117, 112, 110, 102, 103, 98, 101, 102, 102, 94, 94, 92,
                       88, 87, 84, 86, 88, 89, 82, 82, 79, 78, 133, 127, 137, 124, 129, 129,
                       123, 125, 120, 110, 112, 113, 110, 109, 102, 104, 104, 103, 97, 98,
                       96, 93, 90, 90, 79, 72, 75, 128, 121, 122, 126, 121, 115, 114, 114,
                       116, 111, 108, 100, 108, 103, 101, 91, 91, 85])
   }
}
# Simulated Annealing for parameter
def fortuna_optimization(xs, ys, route, initial_theta, max_iters=100000, initial_temp=10.0, cooling_rate=0.999):
    best_theta = initial_theta
    best_loss = float('inf')
    temperature = initial_temp

    #  range for removing noise to the models
    range_min, range_max = -3, 3

    for iteration in tqdm.tqdm(range(max_iters), desc=f"Optimizing {route}"):
        # Generate new_theta within the current range
        new_theta = best_theta + np.random.uniform(range_min, range_max, size=len(best_theta))

        # Calculate the predicted values and the loss
        y_hat = predict(route, xs, new_theta)
        new_loss = get_loss(y_hat, ys)

        # Accept the new theta if it's better or with a probability related to temperature
        if new_loss < best_loss or np.random.rand() < np.exp((best_loss - new_loss) / temperature):
            best_theta = new_theta
            best_loss = new_loss

        # Reduce temperature
        temperature *= cooling_rate

        # Narrow down the sampling range as iterations progress
        range_min = max(-3, range_min * 0.9999)
        range_max = min(3, range_max * 0.9999)

    return best_theta, best_loss

# Function to find the best route for a given departure time
def find_best_route(time, routes_data, thetas):
    best_route = None
    best_duration = float('inf')
    best_cost = float('inf')

    for route_name, route_data in routes_data.items():
        xs = np.array([time]) / 100.0  # Scale the input time similar to the training data
        theta = thetas[route_name]
        predicted_duration = max(0, predict(route_name, xs, theta)[0])  # Ensure duration is non-negative
        cost = estimate_trip_cost(predicted_duration)

        if predicted_duration < best_duration:
            best_route = route_name
            best_duration = predicted_duration
            best_cost = cost

    return best_route, round(best_duration, 2), round(best_cost, 2)

# Ikke en del av oppgaven
# Function to find the random route details for comparison
def find_random_route(time, routes_data, thetas):
    random_route = random.choice(list(routes_data.keys()))  # Choose a random route
    xs = np.array([time]) / 100.0  # Scale the input time similar to the training data
    theta = thetas[random_route]
    predicted_duration = max(0, predict(random_route, xs, theta)[0])  # Ensure duration is non-negative
    cost = estimate_trip_cost(predicted_duration)

    return random_route, round(predicted_duration, 2), round(cost, 2)


# Scale xs
thetas = {}
for route_name, route_data in routes_data.items():
    xs_original = route_data['xs']
    ys = route_data['ys']

    # Scale xs
    scaling_factor = 100.0
    xs_scaled = xs_original / scaling_factor

    # Initialize theta based on the route
    initial_theta = sample_theta(route_name)

    # Optimize the theta parameters using simulated annealing
    best_theta, best_loss = fortuna_optimization(xs_scaled, ys, route_name, initial_theta, max_iters=200000)

    # Store the best theta for each route
    thetas[route_name] = best_theta

    # print the best theta and loss for each route
    print(f"Best theta for route {route_name}: {best_theta}")
    print(f"Best loss for route {route_name}: {best_loss}")

    # make predictions using the optimized theta
    predicted_y = predict(route_name, xs_scaled, best_theta)


    # Plotting as points for actual data and line for predicted data
    plt.figure(figsize=(10, 6))
    plt.scatter(xs_original, ys, color='blue', label='Actual Data')  # Scatter plot for actual data
    plt.plot(xs_original, predicted_y, color='red', label='Predicted Data')  # Line plot for predicted data

    plt.xlabel('Departure Time (minutes)')
    plt.ylabel('Duration (minutes)')
    plt.title(f'Data vs. Model Prediction for route {route_name}')
    plt.legend()
    plt.show()


departure_time = float(input("Enter your planned departure time in minutes: "))  # User input for departure time

# Find the best route using the model
best_route, best_duration, best_cost = find_best_route(departure_time, routes_data, thetas)
print(f"Best route for departure at {departure_time} minutes: {best_route} with estimated duration of {best_duration} minutes and cost of {best_cost} NOK")

# Find a random route for comparison. (ikke en del av oppgaven)
random_route, random_duration, random_cost = find_random_route(departure_time, routes_data, thetas)
print(f"Random route: {random_route} with estimated duration of {random_duration} minutes and cost of {random_cost} NOK")

# Calculate and display the difference
time_saved = round(random_duration - best_duration, 2)
money_saved = round(random_cost - best_cost, 2)

print(f"By choosing the recommended route, you save {time_saved} minutes and {money_saved} NOK.")

total_time_saving = 0
total_cost_saving = 0
num_comparisons = 100  # Number of times to run the comparisons

for _ in range(num_comparisons):
    # Generate a random departure time
    departure_time = random.uniform(0, 1440)  # Random time between 0 and 1440 minutes (full day)

    # Find the optimal route and its duration and cost
    best_route, best_duration, best_cost = find_best_route(departure_time, routes_data, thetas)

    # Choose a random route (different from the best route)
    random_route_name = random.choice([route for route in routes_data.keys() if route != best_route])
    random_theta = thetas[random_route_name]
    random_duration = max(0, predict(random_route_name, np.array([departure_time]) / 100.0, random_theta)[0])
    random_cost = estimate_trip_cost(random_duration)

    # Calculate time and cost savings
    time_saving = random_duration - best_duration
    cost_saving = random_cost - best_cost

    # Accumulate the savings
    total_time_saving += time_saving
    total_cost_saving += cost_saving

# Calculate the average savings
average_time_saving = total_time_saving / num_comparisons
average_cost_saving = total_cost_saving / num_comparisons

# Print the results
print(f"Average time saved per trip: {average_time_saving:.2f} minutes")
print(f"Average cost saved per trip: {average_cost_saving:.2f} NOK")

# Saving thetas after training
import pickle
with open('thetas.pkl', 'wb') as f:
    pickle.dump(thetas, f)

# Loading thetas in the frontend
import pickle
with open('thetas.pkl', 'rb') as f:
    thetas = pickle.load(f)


